# Travis CI Example pipeline
- Build configuration is present in `.travis.yml` in the project.
- Build Status and Link - [![Build Status](https://travis-ci.org/TechPrimers/travis-ci-example.svg?branch=master)](https://travis-ci.org/TechPrimers/travis-ci-example)
- Fork this repo and visit [Travis CI](https://travis-ci.org) to configure your own github account for Continuous Integration and Continuous Deployment
