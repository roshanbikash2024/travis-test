package com.techprimers.ci.travisciexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravisCiExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravisCiExampleApplication.class, args);
	}

}
